import UIKit

final class MemeCollectionCell: UICollectionViewCell {
    @IBOutlet weak var meme: UIImageView!
}

