import UIKit

final class MemeTableCell: UITableViewCell {
    @IBOutlet weak var meme: UIImageView!
    @IBOutlet weak var label: UILabel!
}
